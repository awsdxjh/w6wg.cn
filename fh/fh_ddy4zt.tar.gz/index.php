<?php
error_reporting(0);
header('Content-Type: text/html; charset=UTF-8');
header("Cache-Control: no-store, no-cache");
include 'txprotect.php';
function checkmobile() {
	$useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
	$ualist = array('android', 'midp', 'nokia', 'mobile', 'iphone', 'ipod', 'blackberry', 'windows 

phone');
	foreach($ualist as $v) {
		if(strpos($useragent, $v) !== false) {
			return true;
		}
	}
	if(strpos($_SERVER['HTTP_ACCEPT'], "VND.WAP") !== false || strpos($_SERVER['HTTP_VIA'],"wap") 

!== false){
		return true;
	}
	return false;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/')!==false){
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" style="font-size: 100px;">
<head id="Head1"><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hello World</title>
    <!--禁止全屏缩放-->
<meta name="viewport" content="width=device-width, initial-scale=1.0,minimum-scale=1.0,maximum-

scale=1.0, user-scalable=no">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-

scalable=no" />
    <!--不显示成手机号-->
    <meta name="format-detection" content="telephone=no" />
    <!--删除默认的苹果工具栏和菜单栏-->
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <!--解决UC手机字体变大的问题-->
    <meta name="wap-font-scale" content="no" />
    <!--控制状态栏显示样式-->
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />




<style type="text/css">
@charset "utf-8";

body
{
    background: #ffffff;
    color: #3f3f3f;
    font-family: Apple LiGothic Medium,SimHei,Geneva,Arial,Helvetica,sans-serif;
    -webkit-tap-highlight-color: transparent;
    -webkit-tap-highlight-color: transparent;
    -webkit-touch-callout: none;
    -webkit-appearance: none;
    font-size: 16px;
}
.fc_jt
{
	width: 100%;
}
.fc_jt img
{
	width: 100%;
}

.fc_wz
{
	margin-top: 30px;
	line-height: 40px;
	font-size: 21px;
	text-align: center;
	color: #333333;
	font-family: "Apple LiGothic Medium", SimHei, Geneva, Arial, Helvetica, sans-serif;
}
	.fc_wz img {
		width: 8%;
	}
.fc_tp
{
	margin-top: 110px;
	
}
.fc_tp img
{
	width: 88%;
    text-align: center;
	margin: 0 6% 0;
	border-radius: 10px;
}
</style>


    <script type="text/javascript">
$(function ($) {
    setRootFontSize();
});
window.onresize = function () {
    setRootFontSize();
}
function setRootFontSize() {
    $('html').css('font-size', document.body.clientWidth / 15 + 'px');
}
    </script>
</head>
<body style="background-color: #f5f5f5;">
<div id="Pan_WX">
         <!--QQ访问-->
        <div class="fc_jt">
	<img src="images/jt.jpg" alt=""></div>
               <div class="fc_wz">
               点击屏幕右上角的 <img src="images/index.png" alt=""><br />
  <font size="3">在弹出的窗口中选择 <font color="#FF000">用浏览器打开</font></font></div>  
          <div class="fc_tp"><img src="images/qq.gif"></div>
</div>
</body>
</html>
<?php
}elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')!==false){
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" style="font-size: 100px;">
<head id="Head1"><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hello World</title>
    <!--禁止全屏缩放-->
<meta name="viewport" content="width=device-width, initial-scale=1.0,minimum-scale=1.0,maximum-

scale=1.0, user-scalable=no">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-

scalable=no" />
    <!--不显示成手机号-->
    <meta name="format-detection" content="telephone=no" />
    <!--删除默认的苹果工具栏和菜单栏-->
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <!--解决UC手机字体变大的问题-->
    <meta name="wap-font-scale" content="no" />
    <!--控制状态栏显示样式-->
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />




<style type="text/css">
@charset "utf-8";

body
{
    background: #ffffff;
    color: #3f3f3f;
    font-family: Apple LiGothic Medium,SimHei,Geneva,Arial,Helvetica,sans-serif;
    -webkit-tap-highlight-color: transparent;
    -webkit-tap-highlight-color: transparent;
    -webkit-touch-callout: none;
    -webkit-appearance: none;
    font-size: 16px;
}
.fc_jt
{
	width: 100%;
}
.fc_jt img
{
	width: 100%;
}

.fc_wz
{
	margin-top: 30px;
	line-height: 40px;
	font-size: 21px;
	text-align: center;
	color: #333333;
	font-family: "Apple LiGothic Medium", SimHei, Geneva, Arial, Helvetica, sans-serif;
}
	.fc_wz img {
		width: 8%;
	}
.fc_tp
{
	margin-top: 110px;
	
}
.fc_tp img
{
	width: 88%;
    text-align: center;
	margin: 0 6% 0;
	border-radius: 10px;
}
</style>


    <script type="text/javascript">
$(function ($) {
    setRootFontSize();
});
window.onresize = function () {
    setRootFontSize();
}
function setRootFontSize() {
    $('html').css('font-size', document.body.clientWidth / 15 + 'px');
}
    </script>
</head>
<body style="background-color: #f5f5f5;">
<div id="Pan_WX">
         <!--QQ访问-->
        <div class="fc_jt">
	<img src="images/jt.jpg" alt=""></div>
               <div class="fc_wz">
               点击屏幕右上角的 <img src="images/index.png" alt=""><br />
  <font size="3">在弹出的窗口中选择 <font color="#FF000">用浏览器打开</font></font></div>  
          <div class="fc_tp"><img src="images/wx.gif"></div>
</div>
</body>
</html>
<?php
}else{
	exit('<script>window.location.href="'.$target.'";</script>');
}
?>
